# 🍔 Burger Website

Project website sederhana bertema burger.

## Fitur
- HTML, CSS, JavaScript
- Tampilan sederhana
- Interaksi tombol

## Cara menjalankan
Buka file `index.html` di browser.
